
import React, { useState } from 'react';
import { UserProfile, UserRole, BatchEvent } from '../types';
import { dbService } from '../services/dbService';
import { blockchainService } from '../services/blockchainService';
import { Store, CheckCircle, PackageCheck, AlertCircle } from 'lucide-react';

interface RetailerDashboardProps {
  user: UserProfile;
  onTrace: (id: string) => void;
}

const RetailerDashboard: React.FC<RetailerDashboardProps> = ({ user, onTrace }) => {
  const [batchId, setBatchId] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [shelfLocation, setShelfLocation] = useState('Fresh Produce Section - A1');

  const handleReceive = async (e: React.FormEvent) => {
    e.preventDefault();
    const batch = dbService.getBatch(batchId);
    if (!batch) {
      setError("Batch ID not recognized by the central protocol.");
      return;
    }
    setError(null);
    setLoading(true);

    try {
      let lat = null, lng = null;
      try {
        const pos: any = await new Promise((res, rej) => 
          navigator.geolocation.getCurrentPosition(res, rej, { timeout: 3000 })
        );
        lat = pos.coords.latitude;
        lng = pos.coords.longitude;
      } catch (e) {}

      const eventData = { batchId, shelfLocation, lat, lng, type: 'RETAIL' };
      const dataHash = blockchainService.generateDataHash(eventData);
      const txHash = await blockchainService.submitToBlockchain(dataHash);

      const event: BatchEvent = {
        id: Math.random().toString(36).substr(2, 9),
        batchId,
        role: UserRole.RETAILER,
        userName: user.name,
        timestamp: Date.now(),
        latitude: lat,
        longitude: lng,
        details: { 
          action: 'Received at Retail Outlet',
          shelfLocation
        },
        dataHash,
        txHash
      };

      await dbService.addEvent(event);
      onTrace(batchId);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-white rounded-3xl shadow-2xl border border-gray-100 overflow-hidden">
        <div className="bg-gradient-to-r from-indigo-600 to-indigo-800 p-8 text-white text-center">
          <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-4 backdrop-blur-sm">
            <Store size={32} />
          </div>
          <h1 className="text-3xl font-bold">In-Store Reception</h1>
          <p className="opacity-80 text-sm">Seal the journey and assign retail placement.</p>
        </div>

        <div className="p-10">
          <form onSubmit={handleReceive} className="space-y-6">
            {error && (
              <div className="bg-red-50 border border-red-100 p-4 rounded-xl flex items-center space-x-3 text-red-600 text-sm animate-in shake duration-300">
                <AlertCircle size={20} />
                <span className="font-medium">{error}</span>
              </div>
            )}

            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2 uppercase tracking-wide">Batch ID to Process</label>
              <input 
                required
                value={batchId}
                onChange={(e) => setBatchId(e.target.value.toUpperCase())}
                placeholder="ID: AB-123-XYZ"
                className="w-full px-6 py-5 border-2 border-gray-100 rounded-2xl focus:border-indigo-500 bg-white text-gray-900 outline-none text-2xl font-mono text-center tracking-widest transition shadow-inner"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2 uppercase tracking-wide">Retail Shelf / Bin ID</label>
              <input 
                required
                value={shelfLocation}
                onChange={(e) => setShelfLocation(e.target.value)}
                placeholder="e.g. Aisle 4, Organic Bin"
                className="w-full px-4 py-4 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 bg-white text-gray-900 outline-none transition"
              />
            </div>

            <div className="pt-6">
              <button 
                type="submit"
                disabled={loading}
                className="w-full bg-indigo-600 text-white py-5 rounded-2xl font-bold hover:bg-indigo-700 transition shadow-xl shadow-indigo-100 flex items-center justify-center space-x-3 disabled:opacity-50"
              >
                {loading ? (
                  <span>Syncing Retail Node...</span>
                ) : (
                  <>
                    <PackageCheck size={28} />
                    <span className="text-lg">Finalize Provenance</span>
                  </>
                )}
              </button>
            </div>
          </form>
          <div className="mt-8 pt-8 border-t border-gray-50 text-center">
            <p className="text-xs text-gray-400 uppercase tracking-widest font-semibold">Verified Stakeholder ID: {user.uid}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RetailerDashboard;
