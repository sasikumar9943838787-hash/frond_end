
import React, { useState, useEffect } from 'react';
import { TraceData, UserRole } from '../types';
import { dbService } from '../services/dbService';
import { Search, MapPin, Calendar, Clock, ShieldCheck, ExternalLink, QrCode, Truck, ShoppingCart, Loader2 } from 'lucide-react';

interface CustomerTraceProps {
  batchId: string | null;
}

const CustomerTrace: React.FC<CustomerTraceProps> = ({ batchId: initialBatchId }) => {
  const [searchInput, setSearchInput] = useState('');
  const [traceData, setTraceData] = useState<TraceData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);

  useEffect(() => {
    if (initialBatchId) {
      handleSearch(initialBatchId);
    }
  }, [initialBatchId]);

  const handleSearch = async (id: string) => {
    setLoading(true);
    setError(false);
    try {
      const data = await dbService.getTraceData(id);
      if (data) {
        setTraceData(data);
      } else {
        setError(true);
        setTraceData(null);
      }
    } finally {
      setLoading(false);
    }
  };

  const onFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput) handleSearch(searchInput.toUpperCase());
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12 mb-20">
      {/* Search Bar */}
      <div className="mb-16 text-center animate-in fade-in slide-in-from-bottom-4 duration-700">
        <h2 className="text-4xl font-black text-gray-900 mb-4 tracking-tighter">Chain Discovery</h2>
        <p className="text-gray-500 mb-10 text-lg font-medium">Verify the integrity of your purchase using its unique ledger ID.</p>
        <form onSubmit={onFormSubmit} className="max-w-xl mx-auto flex items-center p-2 bg-white rounded-[2rem] shadow-2xl border border-gray-100 hover:ring-8 transition-all hover:ring-green-50 duration-500">
          <input 
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            className="flex-grow px-6 py-4 rounded-2xl outline-none font-mono tracking-widest uppercase text-xl text-green-600 font-bold placeholder:text-gray-300 placeholder:font-sans placeholder:tracking-normal placeholder:font-normal"
            placeholder="e.g. AG-77-PX"
          />
          <button className="bg-gray-900 text-white p-5 rounded-[1.5rem] hover:bg-black transition-all shadow-xl active:scale-95 duration-200">
            <Search size={24} />
          </button>
        </form>
      </div>

      {loading && (
        <div className="text-center py-20 animate-in fade-in duration-500">
          <div className="relative inline-block">
            <div className="absolute inset-0 bg-green-500 blur-2xl opacity-20 animate-pulse"></div>
            <Loader2 className="animate-spin h-16 w-16 text-green-600 relative z-10" />
          </div>
          <p className="mt-6 text-gray-400 font-mono text-sm tracking-widest uppercase animate-pulse">Decrypting Distributed Records...</p>
        </div>
      )}

      {error && (
        <div className="bg-white p-12 rounded-[2.5rem] border border-red-100 text-center shadow-2xl animate-in zoom-in duration-500">
          <div className="w-16 h-16 bg-red-50 text-red-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <Search size={32} />
          </div>
          <p className="text-gray-900 font-black text-2xl tracking-tight">Record Not Found</p>
          <p className="text-gray-500 mt-2 max-w-xs mx-auto">This ID does not exist on the AgriChain protocol. Please verify the QR code and try again.</p>
        </div>
      )}

      {traceData && (
        <div className="space-y-12">
          {/* Header Card */}
          <div className="bg-white rounded-[3rem] p-10 border border-gray-100 shadow-2xl overflow-hidden relative animate-in slide-in-from-top-10 duration-1000">
            <div className="absolute top-0 right-0 p-10">
              <div className="bg-green-500 text-white px-4 py-2 rounded-2xl text-xs font-black border border-green-400 flex items-center space-x-2 animate-pulse-glow">
                <ShieldCheck size={16} />
                <span className="uppercase tracking-widest">Authenticated Origin</span>
              </div>
            </div>
            
            <div className="flex flex-col md:flex-row gap-10 items-start">
              <div className="w-full md:w-40 h-40 bg-gray-50 rounded-[2.5rem] flex items-center justify-center border-2 border-dashed border-gray-200 animate-float">
                <QrCode size={64} className="text-green-600" />
              </div>
              <div className="flex-grow">
                <span className="inline-block px-3 py-1 bg-green-100 text-green-700 text-[10px] font-black rounded-lg uppercase tracking-widest mb-3">Certified Harvest</span>
                <h3 className="text-5xl font-black text-gray-900 mb-2 tracking-tighter">{traceData.batch.crop}</h3>
                <p className="text-2xl text-emerald-600 font-bold mb-6 italic">"{traceData.batch.seedType}"</p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
                  <div>
                    <span className="text-[10px] text-gray-400 block mb-1 uppercase font-black tracking-widest">Chain ID</span>
                    <span className="font-mono text-sm text-gray-700 bg-gray-50 px-2 py-1 rounded-md">#{traceData.batch.id}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-gray-400 block mb-1 uppercase font-black tracking-widest">Weight</span>
                    <span className="text-gray-900 font-bold">{traceData.batch.quantity}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-gray-400 block mb-1 uppercase font-black tracking-widest">Source</span>
                    <span className="text-gray-900 font-bold">{traceData.batch.location}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-gray-400 block mb-1 uppercase font-black tracking-widest">Sealed</span>
                    <span className="text-gray-900 font-bold">{new Date(traceData.batch.harvestDate).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Timeline */}
          <div className="relative pt-10">
            <h4 className="text-3xl font-black mb-12 text-gray-900 tracking-tighter ml-4">Custody Flow</h4>
            
            <div className="space-y-16 relative before:absolute before:left-10 before:top-4 before:bottom-4 before:w-1 before:bg-gradient-to-b before:from-green-500 before:via-blue-500 before:to-indigo-500 before:rounded-full">
              {traceData.events.map((event, idx) => (
                <div 
                  key={event.id} 
                  className={`relative pl-24 animate-in slide-in-from-left-8 duration-700`}
                  style={{ animationDelay: `${idx * 200}ms`, animationFillMode: 'both' }}
                >
                  <div className={`absolute left-0 top-0 w-20 h-20 bg-white rounded-[2rem] shadow-2xl border-4 flex items-center justify-center z-10 transition-transform hover:scale-110 duration-300
                    ${event.role === UserRole.FARMER ? 'border-green-500' : ''}
                    ${event.role === UserRole.DISTRIBUTOR ? 'border-blue-500' : ''}
                    ${event.role === UserRole.RETAILER ? 'border-indigo-500' : ''}
                  `}>
                    {event.role === UserRole.FARMER && <MapPin className="text-green-600" size={32} />}
                    {event.role === UserRole.DISTRIBUTOR && <Truck className="text-blue-600" size={32} />}
                    {event.role === UserRole.RETAILER && <ShoppingCart className="text-indigo-600" size={32} />}
                  </div>

                  <div className="bg-white/80 glass p-8 rounded-[2.5rem] border border-white shadow-xl hover:shadow-2xl transition-all duration-500 group">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6 gap-4">
                      <div>
                        <span className={`inline-block px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest mb-2
                          ${event.role === UserRole.FARMER ? 'bg-green-100 text-green-700' : ''}
                          ${event.role === UserRole.DISTRIBUTOR ? 'bg-blue-100 text-blue-700' : ''}
                          ${event.role === UserRole.RETAILER ? 'bg-indigo-100 text-indigo-700' : ''}
                        `}>
                          {event.role} NODE
                        </span>
                        <h5 className="text-2xl font-bold text-gray-900 tracking-tight">{event.details.action}</h5>
                      </div>
                      <div className="text-right flex flex-col items-end">
                        <div className="flex items-center space-x-3 text-sm text-gray-500 font-bold bg-gray-50 px-4 py-2 rounded-2xl">
                          <Calendar size={16} />
                          <span>{new Date(event.timestamp).toLocaleDateString()}</span>
                          <span className="text-gray-300">|</span>
                          <Clock size={16} />
                          <span>{new Date(event.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 mb-8">
                      {Object.entries(event.details).map(([key, value]) => {
                        if (key === 'action') return null;
                        return (
                          <div key={key} className="bg-gray-50/50 p-4 rounded-2xl border border-gray-100/50">
                            <span className="text-[10px] text-gray-400 capitalize font-black tracking-widest mb-1 block">{key.replace(/([A-Z])/g, ' $1')}</span>
                            <p className="text-md font-bold text-gray-800">{String(value)}</p>
                          </div>
                        );
                      })}
                      {event.latitude && (
                        <div className="bg-green-50/50 p-4 rounded-2xl border border-green-100/50">
                          <span className="text-[10px] text-green-600/60 uppercase font-black tracking-widest mb-1 block">Geo-Tag Position</span>
                          <p className="text-md font-mono font-bold text-green-800">
                            {event.latitude.toFixed(6)}°N, {event.longitude?.toFixed(6)}°E
                          </p>
                        </div>
                      )}
                    </div>

                    <div className="pt-6 border-t border-gray-100 flex flex-col sm:flex-row items-center justify-between gap-4">
                      <div className="flex items-center space-x-3 text-emerald-600">
                        <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_5px_#10b981]"></div>
                        <span className="text-[11px] font-black uppercase tracking-widest">Verified Cryptographic Signature</span>
                      </div>
                      <button 
                        onClick={(e) => { e.preventDefault(); alert(`Full Blockchain Receipt:\n\nHash: ${event.dataHash}\nTx: ${event.txHash}`); }}
                        className="text-gray-400 hover:text-green-600 text-[10px] font-black uppercase tracking-widest flex items-center space-x-2 transition-colors duration-300 group"
                      >
                        <span className="group-hover:underline">View Block Receipt</span>
                        <ExternalLink size={14} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CustomerTrace;
