
import React, { useState } from 'react';
import { UserRole } from '../types';
import { authService } from '../services/authService';
import { ShieldCheck, QrCode, MapPin, Truck, UserPlus, LogIn, AlertCircle, Loader2, Leaf, ArrowRight, CheckCircle } from 'lucide-react';

interface LandingPageProps {
  onLogin: (email: string, role: UserRole) => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onLogin }) => {
  const [isRegistering, setIsRegistering] = useState(false);
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState<UserRole>(UserRole.FARMER);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      if (isRegistering) {
        if (!name || !email) throw new Error("Please fill in all fields.");
        const user = await authService.signup(name, email, role);
        onLogin(user.email, user.role);
      } else {
        if (!email) throw new Error("Please enter your email.");
        const user = await authService.login(email, role);
        onLogin(user.email, user.role);
      }
    } catch (err: any) {
      setError(err.message || "An unexpected error occurred.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative min-h-[90vh] flex flex-col items-center justify-center">
      {/* Background Flow SVG */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        <svg className="w-full h-full" viewBox="0 0 1440 800" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path 
            className="animate-flow-path" 
            d="M-100 600C200 500 400 700 700 400C1000 100 1200 300 1540 100" 
            stroke="#16a34a" 
            strokeWidth="2" 
          />
          <path 
            className="animate-flow-path" 
            style={{ animationDelay: '-5s' }}
            d="M-100 200C300 100 600 500 900 300C1200 100 1400 400 1540 600" 
            stroke="#16a34a" 
            strokeWidth="2" 
          />
        </svg>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-12 lg:py-24 grid lg:grid-cols-2 gap-16 items-center relative z-10">
        {/* Hero Section */}
        <div className="animate-reveal">
          <div className="inline-flex items-center space-x-2 bg-green-50 text-green-700 px-4 py-2 rounded-2xl mb-8 border border-green-100 shadow-sm">
            <Leaf size={18} className="animate-soft-float" />
            <span className="text-sm font-bold tracking-tight">Sustainable Supply Chain 3.0</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-extrabold text-gray-900 leading-[1.1] mb-8 tracking-tight">
            Traceability <br/>
            <span className="text-green-600">Built on Truth.</span>
          </h1>
          
          <p className="text-xl text-gray-600 mb-10 max-w-xl leading-relaxed">
            AgriChain connects farmers, distributors, and consumers in an immutable network of trust. Every scan verifies a journey.
          </p>

          <div className="grid grid-cols-2 gap-6 mb-12">
            <div className="flex items-center space-x-3 p-4 bg-white rounded-2xl shadow-sm border border-gray-100 group hover:border-green-500 transition-colors duration-300">
              <div className="bg-green-100 p-2 rounded-xl text-green-600 group-hover:bg-green-600 group-hover:text-white transition-all">
                <ShieldCheck size={20} />
              </div>
              <span className="font-bold text-gray-800">Tamper-Proof</span>
            </div>
            <div className="flex items-center space-x-3 p-4 bg-white rounded-2xl shadow-sm border border-gray-100 group hover:border-green-500 transition-colors duration-300">
              <div className="bg-green-100 p-2 rounded-xl text-green-600 group-hover:bg-green-600 group-hover:text-white transition-all">
                <MapPin size={20} />
              </div>
              <span className="font-bold text-gray-800">Real-time GPS</span>
            </div>
          </div>
        </div>

        {/* Form Card */}
        <div className="animate-reveal stagger-1">
          <div className="glass-premium p-10 rounded-[2.5rem] relative overflow-hidden group">
            {/* Visual glow on hover */}
            <div className="absolute -top-24 -right-24 w-64 h-64 bg-green-500/5 blur-3xl rounded-full group-hover:bg-green-500/10 transition-colors duration-500"></div>

            <div className="flex justify-between items-center mb-10">
              <div>
                <h2 className="text-3xl font-black text-gray-900 tracking-tight">
                  {isRegistering ? 'Register Entity' : 'Node Login'}
                </h2>
                <p className="text-sm text-gray-500 font-medium mt-1">Authenticate with the AgriChain ledger</p>
              </div>
              <div className="bg-green-600 p-4 rounded-2xl shadow-lg shadow-green-100 animate-soft-float">
                {isRegistering ? <UserPlus className="text-white" /> : <LogIn className="text-white" />}
              </div>
            </div>

            {error && (
              <div className="mb-6 p-4 bg-red-50 border border-red-100 rounded-2xl flex items-center space-x-3 text-red-600 text-sm animate-in zoom-in duration-300">
                <AlertCircle size={20} className="flex-shrink-0" />
                <p className="font-semibold">{error}</p>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-5">
              {isRegistering && (
                <div className="animate-reveal stagger-1">
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2 ml-1">Company/Farm Name</label>
                  <input 
                    type="text" 
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Green Valley Farm"
                    className="w-full px-5 py-4 rounded-2xl border border-gray-100 focus:ring-4 focus:ring-green-500/10 focus:border-green-500 bg-white/50 text-gray-900 outline-none transition-all shadow-sm font-medium"
                    required={isRegistering}
                  />
                </div>
              )}

              <div className="animate-reveal stagger-2">
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2 ml-1">Work Email</label>
                <input 
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@company.com"
                  className="w-full px-5 py-4 rounded-2xl border border-gray-100 focus:ring-4 focus:ring-green-500/10 focus:border-green-500 bg-white/50 text-gray-900 outline-none transition-all shadow-sm font-medium"
                  required
                />
              </div>

              <div className="animate-reveal stagger-3">
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2 ml-1">Network Role</label>
                <div className="relative">
                  <select 
                    value={role}
                    onChange={(e) => setRole(e.target.value as UserRole)}
                    className="w-full px-5 py-4 rounded-2xl border border-gray-100 focus:ring-4 focus:ring-green-500/10 focus:border-green-500 bg-white/50 text-gray-900 outline-none transition-all shadow-sm font-bold appearance-none cursor-pointer"
                  >
                    <option value={UserRole.FARMER}>Farmer (Producer)</option>
                    <option value={UserRole.DISTRIBUTOR}>Distributor (Carrier)</option>
                    <option value={UserRole.RETAILER}>Retailer (Market)</option>
                  </select>
                  <div className="absolute right-5 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400">
                    ▼
                  </div>
                </div>
              </div>

              <div className="pt-4 animate-reveal stagger-4">
                <button 
                  type="submit"
                  disabled={loading}
                  className="w-full bg-green-600 text-white py-5 rounded-2xl font-bold text-lg hover:bg-green-700 transition-all shadow-xl shadow-green-100 flex items-center justify-center space-x-2 disabled:opacity-70 active:scale-[0.98] duration-200 btn-pulse"
                >
                  {loading ? (
                    <>
                      <Loader2 className="animate-spin" size={24} />
                      <span className="uppercase tracking-widest text-sm">Validating ID...</span>
                    </>
                  ) : (
                    <>
                      <span>{isRegistering ? 'Initialize Profile' : 'Enter Dashboard'}</span>
                      <ArrowRight size={20} />
                    </>
                  )}
                </button>
              </div>
            </form>

            <div className="mt-8 text-center">
              <button 
                onClick={() => {
                  setIsRegistering(!isRegistering);
                  setError(null);
                }}
                className="text-sm font-bold text-green-600 hover:text-green-700 transition-all px-6 py-2 rounded-xl hover:bg-green-50"
              >
                {isRegistering 
                  ? 'Already have a node? Log In' 
                  : 'Register a New Network ID'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Feature Section with Hover States */}
      <div className="max-w-7xl mx-auto px-6 py-12 grid md:grid-cols-4 gap-6 w-full animate-reveal stagger-4">
        {[
          { icon: <CheckCircle />, title: "Provenance", desc: "Absolute proof of origin." },
          { icon: <Truck />, title: "Logistics", desc: "Live custody handovers." },
          { icon: <ShieldCheck />, title: "Immutable", desc: "Blockchain verification." },
          { icon: <QrCode />, title: "Traceable", desc: "One QR, complete history." },
        ].map((feat, i) => (
          <div key={i} className="bg-white p-6 rounded-3xl border border-gray-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-500 group text-center lg:text-left">
            <div className="bg-green-50 w-12 h-12 flex items-center justify-center rounded-2xl mb-4 mx-auto lg:mx-0 text-green-600 group-hover:bg-green-600 group-hover:text-white transition-all duration-500">
              {feat.icon}
            </div>
            <h4 className="font-bold text-gray-900 mb-1">{feat.title}</h4>
            <p className="text-sm text-gray-500 font-medium">{feat.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default LandingPage;
