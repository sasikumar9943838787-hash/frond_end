
import React, { useState } from 'react';
import { UserProfile, UserRole, BatchEvent } from '../types';
import { dbService } from '../services/dbService';
import { blockchainService } from '../services/blockchainService';
import { Truck, Scan, CheckCircle, Navigation } from 'lucide-react';

interface DistributorDashboardProps {
  user: UserProfile;
  onTrace: (id: string) => void;
}

const DistributorDashboard: React.FC<DistributorDashboardProps> = ({ user, onTrace }) => {
  const [batchId, setBatchId] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    transportMode: 'Truck - Refrigerated',
    temp: '4°C',
    carrier: 'Fast-Track Logistics'
  });

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    const batch = dbService.getBatch(batchId);
    if (!batch) {
      alert("Invalid Batch ID - Data not found on chain.");
      return;
    }

    setLoading(true);
    try {
      // Capture Geo
      let lat = null, lng = null;
      try {
        const pos: any = await new Promise((res, rej) => 
          navigator.geolocation.getCurrentPosition(res, rej, { timeout: 3000 })
        );
        lat = pos.coords.latitude;
        lng = pos.coords.longitude;
      } catch (e) {}

      const eventData = { batchId, ...formData, lat, lng, type: 'TRANSIT' };
      const dataHash = blockchainService.generateDataHash(eventData);
      const txHash = await blockchainService.submitToBlockchain(dataHash);

      const event: BatchEvent = {
        id: Math.random().toString(36).substr(2, 9),
        batchId,
        role: UserRole.DISTRIBUTOR,
        userName: user.name,
        timestamp: Date.now(),
        latitude: lat,
        longitude: lng,
        details: { 
          action: 'Picked up for distribution',
          ...formData
        },
        dataHash,
        txHash
      };

      await dbService.addEvent(event);
      setSuccess(batchId);
      setBatchId('');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-700">
      <div>
        <h1 className="text-4xl font-black text-gray-900 tracking-tighter">Distributor Portal</h1>
        <p className="text-gray-500 font-medium">Global Logistics & Environmental Integrity Node</p>
      </div>

      {success && (
        <div className="bg-green-600 p-5 rounded-3xl flex items-center justify-between text-white shadow-2xl shadow-green-200 animate-in slide-in-from-top-6 duration-500">
          <div className="flex items-center space-x-4">
            <div className="bg-white/20 p-2 rounded-full animate-pulse">
              <CheckCircle size={28} />
            </div>
            <div>
              <p className="font-bold text-lg">Event Sealed Successfully</p>
              <p className="text-xs opacity-80 font-mono">{success}</p>
            </div>
          </div>
          <button 
            onClick={() => onTrace(success)}
            className="bg-white text-green-700 px-6 py-2 rounded-2xl text-sm font-black hover:bg-gray-100 transition-all active:scale-95"
          >
            Audit Now
          </button>
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-8">
        <div className="bg-white p-10 rounded-[2.5rem] shadow-xl border border-gray-100">
          <div className="flex items-center space-x-4 mb-8">
            <div className="bg-blue-100 p-3 rounded-2xl animate-float">
              <Truck className="text-blue-600" size={28} />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 tracking-tight">Custody Sync</h2>
          </div>

          <form onSubmit={handleUpdate} className="space-y-6">
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2 ml-1">Hardware ID / QR</label>
              <div className="relative">
                <input 
                  required
                  value={batchId}
                  onChange={(e) => setBatchId(e.target.value.toUpperCase())}
                  placeholder="e.g. AG-X-449"
                  className="w-full px-5 py-4 border border-gray-100 rounded-2xl focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 bg-gray-50 text-gray-900 outline-none uppercase font-mono transition-all text-lg"
                />
                <button 
                  type="button"
                  className="absolute right-4 top-1/2 -translate-y-1/2 p-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-all shadow-lg shadow-blue-200"
                >
                  <Scan size={20} />
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2 ml-1">Asset Configuration</label>
              <select 
                value={formData.transportMode}
                onChange={(e) => setFormData({...formData, transportMode: e.target.value})}
                className="w-full px-5 py-4 border border-gray-100 rounded-2xl focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 bg-gray-50 text-gray-900 outline-none transition-all appearance-none cursor-pointer"
              >
                <option>Truck - Cold Chain</option>
                <option>Truck - Standard</option>
                <option>Air Express</option>
                <option>Maritime Freight</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2 ml-1">Sensor Metrics</label>
              <input 
                value={formData.temp}
                onChange={(e) => setFormData({...formData, temp: e.target.value})}
                placeholder="4°C | 55% RH"
                className="w-full px-5 py-4 border border-gray-100 rounded-2xl focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 bg-gray-50 text-gray-900 outline-none transition-all"
              />
            </div>

            <div className="pt-4">
              <button 
                type="submit"
                disabled={loading}
                className="w-full bg-blue-600 text-white py-5 rounded-2xl font-bold hover:bg-blue-700 transition-all shadow-2xl shadow-blue-100 flex items-center justify-center space-x-3 disabled:opacity-50 active:scale-95"
              >
                {loading ? (
                  <span className="flex items-center space-x-2">
                    <Loader2 className="animate-spin" />
                    <span>Propagating to Mainnet...</span>
                  </span>
                ) : (
                  <>
                    <Navigation size={22} />
                    <span className="text-lg">Update Logistics Node</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>

        <div className="bg-gray-900 p-10 rounded-[2.5rem] shadow-2xl relative overflow-hidden flex flex-col items-center justify-center text-center">
          {/* Cyber Scan Line */}
          <div className="absolute left-0 w-full h-0.5 bg-green-500 shadow-[0_0_15px_#22c55e] animate-scan z-30"></div>
          
          <div className="relative z-20">
            <div className="w-24 h-24 bg-white/10 rounded-[2rem] flex items-center justify-center mb-6 shadow-2xl border border-white/10 animate-float">
              <Scan size={44} className="text-green-500" />
            </div>
            <h3 className="font-bold text-2xl text-white mb-3">Live Vision Mode</h3>
            <p className="text-gray-400 text-sm max-w-xs leading-relaxed">
              Place the Batch QR code within the highlighted focus area for rapid asset identification.
            </p>
            
            <div className="mt-12 p-8 border-2 border-dashed border-green-500/30 rounded-3xl bg-green-500/5 backdrop-blur-sm">
              <div className="flex items-center justify-center space-x-3 text-green-500">
                <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse shadow-[0_0_10px_#22c55e]"></div>
                <p className="text-sm font-mono font-bold tracking-widest uppercase">Scanner Active</p>
              </div>
            </div>
          </div>

          {/* Grid Background Effect */}
          <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: 'radial-gradient(#22c55e 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>
        </div>
      </div>
    </div>
  );
};

// Re-using Loader2 from LandingPage if needed, or define locally if not available
const Loader2 = ({ className }: { className?: string }) => (
  <svg className={`animate-spin h-5 w-5 ${className}`} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
  </svg>
);

export default DistributorDashboard;
